#include "pic.h"
#include "ports.h"

namespace {
    constexpr u16 PIC1_CMD  = 0x20;
    constexpr u16 PIC1_DATA = 0x21;
    constexpr u16 PIC2_CMD  = 0xA0;
    constexpr u16 PIC2_DATA = 0xA1;

    constexpr u8 ICW1_INIT = 0x10;
    constexpr u8 ICW1_ICW4 = 0x01;
    constexpr u8 ICW4_8086 = 0x01;
}

void pic_remap() {
    u8 mask1 = inb(PIC1_DATA);
    u8 mask2 = inb(PIC2_DATA);

    outb(PIC1_CMD, ICW1_INIT | ICW1_ICW4); io_wait();
    outb(PIC2_CMD, ICW1_INIT | ICW1_ICW4); io_wait();

    outb(PIC1_DATA, 32); io_wait();       // master IRQ0 -> vector 32
    outb(PIC2_DATA, 40); io_wait();       // slave IRQ8 -> vector 40

    outb(PIC1_DATA, 4); io_wait();        // tell master about slave at IRQ2
    outb(PIC2_DATA, 2); io_wait();        // tell slave its cascade identity

    outb(PIC1_DATA, ICW4_8086); io_wait();
    outb(PIC2_DATA, ICW4_8086); io_wait();

    outb(PIC1_DATA, mask1);
    outb(PIC2_DATA, mask2);
}

void pic_send_eoi(u8 irq) {
    if (irq >= 8) outb(PIC2_CMD, 0x20);
    outb(PIC1_CMD, 0x20);
}

void pic_set_mask(u8 irq) {
    u16 port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    u8 bit = irq < 8 ? irq : irq - 8;
    u8 value = inb(port) | (1 << bit);
    outb(port, value);
}

void pic_clear_mask(u8 irq) {
    u16 port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    u8 bit = irq < 8 ? irq : irq - 8;
    u8 value = inb(port) & ~(1 << bit);
    outb(port, value);
}
