#include "idt.h"
#include "gdt.h"
#include "pic.h"
#include "serial.h"
#include "vga.h"

extern "C" void load_idt(void* ptr);

// ISR/IRQ stub entry points defined in interrupts/isr_stubs.asm
#define ISR_LIST(X) \
    X(0) X(1) X(2) X(3) X(4) X(5) X(6) X(7) X(8) X(9) \
    X(10) X(11) X(12) X(13) X(14) X(15) X(16) X(17) X(18) X(19) \
    X(20) X(21) X(22) X(23) X(24) X(25) X(26) X(27) X(28) X(29) \
    X(30) X(31)

#define IRQ_LIST(X) \
    X(0) X(1) X(2) X(3) X(4) X(5) X(6) X(7) X(8) X(9) \
    X(10) X(11) X(12) X(13) X(14) X(15)

#define DECL_ISR(n) extern "C" void isr_stub_##n();
#define DECL_IRQ(n) extern "C" void irq_stub_##n();
ISR_LIST(DECL_ISR)
IRQ_LIST(DECL_IRQ)
#undef DECL_ISR
#undef DECL_IRQ

namespace idt {

namespace {
    struct __attribute__((packed)) gate {
        u16 offset_low;
        u16 selector;
        u8  ist;
        u8  type_attr;
        u16 offset_mid;
        u32 offset_high;
        u32 reserved;
    };

    struct __attribute__((packed)) descriptor_ptr {
        u16 limit;
        u64 base;
    };

    constexpr int NUM_VECTORS = 256;
    gate table[NUM_VECTORS];
    handler_fn handlers[NUM_VECTORS];

    void set_gate(int vec, void (*fn)(), u8 ist = 0) {
        u64 addr = reinterpret_cast<u64>(fn);
        table[vec].offset_low  = addr & 0xFFFF;
        table[vec].selector    = gdt::KERNEL_CODE_SEL;
        table[vec].ist         = ist & 0x7;
        table[vec].type_attr   = 0x8E; // present, DPL0, 64-bit interrupt gate
        table[vec].offset_mid  = (addr >> 16) & 0xFFFF;
        table[vec].offset_high = static_cast<u32>(addr >> 32);
        table[vec].reserved    = 0;
    }

    const char* exception_name(u64 vec) {
        static const char* names[32] = {
            "Divide Error", "Debug", "NMI", "Breakpoint",
            "Overflow", "BOUND Range", "Invalid Opcode", "Device N/A",
            "Double Fault", "Coproc Overrun", "Invalid TSS", "Segment N/P",
            "Stack Fault", "GPF", "Page Fault", "Reserved",
            "x87 FP", "Alignment Check", "Machine Check", "SIMD FP",
            "Virtualization", "Control Protection", "Reserved", "Reserved",
            "Reserved", "Reserved", "Reserved", "Reserved",
            "Hypervisor Injection", "VMM Communication", "Security", "Reserved",
        };
        return vec < 32 ? names[vec] : "Unknown";
    }

    void default_exception_handler(registers* regs) {
        vga::set_color(vga::Color::White, vga::Color::Red);
        vga::write("\n*** KERNEL PANIC: ");
        vga::write(exception_name(regs->vector));
        vga::write(" ***\n");
        vga::write("vector="); vga::write_dec(regs->vector);
        vga::write(" error="); vga::write_hex(regs->error_code);
        vga::write(" rip="); vga::write_hex(regs->rip);
        vga::write("\n");

        serial::write("\n[PANIC] ");
        serial::write(exception_name(regs->vector));
        serial::write(" vector="); serial::write_dec(regs->vector);
        serial::write(" error="); serial::write_hex(regs->error_code);
        serial::write(" rip="); serial::write_hex(regs->rip);
        serial::write("\n");

        asm volatile("cli");
        for (;;) asm volatile("hlt");
    }

    void default_irq_handler(registers*) {
        // Unhandled IRQ - ignore. PIC EOI is sent by the owning driver or
        // the generic fallback in pic.cpp.
    }
}

void init() {
    for (int i = 0; i < NUM_VECTORS; i++) {
        handlers[i] = default_irq_handler;
    }

#define SET_ISR(n) set_gate(n, isr_stub_##n, (n == 8) ? 1 : 0); handlers[n] = default_exception_handler;
    ISR_LIST(SET_ISR)
#undef SET_ISR

#define SET_IRQ(n) set_gate(32 + n, irq_stub_##n);
    IRQ_LIST(SET_IRQ)
#undef SET_IRQ

    static descriptor_ptr ptr;
    ptr.limit = sizeof(table) - 1;
    ptr.base = reinterpret_cast<u64>(&table);
    load_idt(&ptr);
}

void register_handler(u8 vector, handler_fn fn) {
    handlers[vector] = fn;
}

void dispatch(registers* regs) {
    handlers[regs->vector](regs);

    if (regs->vector >= 32 && regs->vector <= 47) {
        pic_send_eoi(static_cast<u8>(regs->vector - 32));
    }
}

} // namespace idt

extern "C" void isr_common_dispatch(idt::registers* regs) {
    idt::dispatch(regs);
}
