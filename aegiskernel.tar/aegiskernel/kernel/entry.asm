; ============================================================================
; aegiskernel - Kernel Entry (64-bit)
; ============================================================================
; This must be the very first code in the linked binary (see linker.ld).
; Landed on from stage2 with:
;   RDI = pointer to boot_info struct (physical address, identity-mapped)
;   Paging enabled, identity-mapped 0..64MiB, running in ring 0.
; ============================================================================

BITS 64

section .text.entry
global _start
extern kmain

_start:
    mov rsp, kernel_stack_top
    mov rbp, rsp

    ; rdi already holds boot_info* per stage2 calling convention - pass through
    call kmain

.hang:
    cli
    hlt
    jmp .hang

; ----------------------------------------------------------------------
; ISR/IRQ common stub + dispatcher glue (see interrupts/isr_stubs.asm)
; ----------------------------------------------------------------------
global load_gdt
load_gdt:
    lgdt [rdi]
    mov ax, 0x10          ; kernel data selector
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    push 0x08              ; kernel code selector
    lea rax, [rel .flush]
    push rax
    retfq
.flush:
    ret

global load_idt
load_idt:
    lidt [rdi]
    ret

global load_tss
load_tss:
    ltr di
    ret

section .bss
align 16
kernel_stack_bottom:
    resb 64 * 1024          ; 64 KiB boot stack
kernel_stack_top:
