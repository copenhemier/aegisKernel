#include "gdt.h"

extern "C" void load_gdt(gdt::descriptor_ptr* ptr);
extern "C" void load_tss(u16 selector);

namespace gdt {

namespace {
    // null, kcode, kdata, tss_low, tss_high  (TSS descriptor is 16 bytes = 2 slots)
    entry table[5];
    tss_entry tss;
    descriptor_ptr ptr;

    void set_entry(int i, u32 base, u32 limit, u8 access, u8 gran) {
        table[i].base_low    = base & 0xFFFF;
        table[i].base_mid    = (base >> 16) & 0xFF;
        table[i].base_high   = (base >> 24) & 0xFF;
        table[i].limit_low   = limit & 0xFFFF;
        table[i].granularity = (gran & 0xF0) | ((limit >> 16) & 0x0F);
        table[i].access      = access;
    }

    void set_tss_descriptor(int i, u64 base, u32 limit) {
        // 64-bit TSS descriptor occupies two 8-byte GDT slots.
        auto* raw = reinterpret_cast<u8*>(&table[i]);
        raw[0] = limit & 0xFF;
        raw[1] = (limit >> 8) & 0xFF;
        raw[2] = base & 0xFF;
        raw[3] = (base >> 8) & 0xFF;
        raw[4] = (base >> 16) & 0xFF;
        raw[5] = 0x89;              // present, DPL0, type=64-bit TSS (available)
        raw[6] = ((limit >> 16) & 0x0F);
        raw[7] = (base >> 24) & 0xFF;

        auto* raw2 = reinterpret_cast<u8*>(&table[i + 1]);
        u32 base_upper = static_cast<u32>(base >> 32);
        raw2[0] = base_upper & 0xFF;
        raw2[1] = (base_upper >> 8) & 0xFF;
        raw2[2] = (base_upper >> 16) & 0xFF;
        raw2[3] = (base_upper >> 24) & 0xFF;
        raw2[4] = 0; raw2[5] = 0; raw2[6] = 0; raw2[7] = 0;
    }
}

void init() {
    set_entry(0, 0, 0, 0, 0);                          // null
    set_entry(1, 0, 0xFFFFF, 0x9A, 0xA0);               // kernel code, 64-bit
    set_entry(2, 0, 0xFFFFF, 0x92, 0xA0);               // kernel data

    for (auto& b : reinterpret_cast<u8(&)[sizeof(tss)]>(tss)) b = 0;
    tss.iomap_base = sizeof(tss_entry);

    set_tss_descriptor(3, reinterpret_cast<u64>(&tss), sizeof(tss_entry) - 1);

    ptr.limit = sizeof(table) - 1;
    ptr.base = reinterpret_cast<u64>(&table);

    load_gdt(&ptr);
    load_tss(TSS_SEL);
}

void set_ist1(uptr stack_top) {
    tss.ist[0] = stack_top;
}

} // namespace gdt
