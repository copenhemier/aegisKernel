#include "keyboard.h"
#include "ports.h"
#include "idt.h"
#include "pic.h"

namespace keyboard {

namespace {
    constexpr u16 DATA_PORT = 0x60;
    constexpr int BUF_SIZE = 256;

    volatile char ring_buf[BUF_SIZE];
    volatile int head = 0;
    volatile int tail = 0;
    bool shift_held = false;

    // Scancode set 1 -> ASCII (unshifted), US QWERTY, index = scancode
    const char scancode_ascii[128] = {
        0, 27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
        '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
        0 /*ctrl*/, 'a','s','d','f','g','h','j','k','l',';','\'','`',
        0 /*lshift*/, '\\','z','x','c','v','b','n','m',',','.','/',
        0 /*rshift*/, '*', 0 /*alt*/, ' ', 0 /*capslock*/,
        0,0,0,0,0,0,0,0,0,0, // F1-F10
        0 /*numlock*/, 0 /*scrolllock*/,
        0,0,0,0,0,0,0,0,0, // keypad
        0,0,0, // more keypad
        0,0, // F11/F12
    };

    const char scancode_ascii_shift[128] = {
        0, 27, '!','@','#','$','%','^','&','*','(',')','_','+','\b',
        '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
        0, 'A','S','D','F','G','H','J','K','L',':','"','~',
        0, '|','Z','X','C','V','B','N','M','<','>','?',
        0, '*', 0, ' ', 0,
        0,0,0,0,0,0,0,0,0,0,
        0, 0,
        0,0,0,0,0,0,0,0,0,
        0,0,0,
        0,0,
    };

    constexpr u8 SC_LSHIFT = 0x2A;
    constexpr u8 SC_RSHIFT = 0x36;
    constexpr u8 RELEASE_BIT = 0x80;

    void push_char(char c) {
        int next = (head + 1) % BUF_SIZE;
        if (next == tail) return; // buffer full, drop
        ring_buf[head] = c;
        head = next;
    }

    void irq_handler(idt::registers*) {
        u8 sc = inb(DATA_PORT);
        bool released = (sc & RELEASE_BIT) != 0;
        u8 code = sc & 0x7F;

        if (code == SC_LSHIFT || code == SC_RSHIFT) {
            shift_held = !released;
            return;
        }

        if (released) return;
        if (code >= 128) return;

        char c = shift_held ? scancode_ascii_shift[code] : scancode_ascii[code];
        if (c) push_char(c);
    }
}

void init() {
    idt::register_handler(33, irq_handler); // IRQ1
    pic_clear_mask(1);
}

bool has_char() {
    return head != tail;
}

char read_char() {
    while (!has_char()) {
        asm volatile("hlt");
    }
    char c = ring_buf[tail];
    tail = (tail + 1) % BUF_SIZE;
    return c;
}

} // namespace keyboard
