#include "vga.h"
#include "ports.h"

namespace vga {

namespace {
    constexpr uptr VGA_MEM = 0xB8000;
    constexpr int WIDTH = 80;
    constexpr int HEIGHT = 25;

    volatile u16* const buffer = reinterpret_cast<volatile u16*>(VGA_MEM);
    int cursor_x = 0;
    int cursor_y = 0;
    u8 current_color = 0x0F; // white on black

    inline u16 make_entry(char c, u8 color) {
        return static_cast<u16>(c) | (static_cast<u16>(color) << 8);
    }

    void move_hw_cursor() {
        u16 pos = static_cast<u16>(cursor_y * WIDTH + cursor_x);
        outb(0x3D4, 0x0F);
        outb(0x3D5, static_cast<u8>(pos & 0xFF));
        outb(0x3D4, 0x0E);
        outb(0x3D5, static_cast<u8>((pos >> 8) & 0xFF));
    }

    void scroll() {
        if (cursor_y < HEIGHT) return;
        for (int row = 1; row < HEIGHT; row++) {
            for (int col = 0; col < WIDTH; col++) {
                buffer[(row - 1) * WIDTH + col] = buffer[row * WIDTH + col];
            }
        }
        for (int col = 0; col < WIDTH; col++) {
            buffer[(HEIGHT - 1) * WIDTH + col] = make_entry(' ', current_color);
        }
        cursor_y = HEIGHT - 1;
    }
} // namespace

void init() {
    current_color = 0x0F;
    clear();
}

void clear() {
    for (int i = 0; i < WIDTH * HEIGHT; i++) {
        buffer[i] = make_entry(' ', current_color);
    }
    cursor_x = 0;
    cursor_y = 0;
    move_hw_cursor();
}

void set_color(Color fg, Color bg) {
    current_color = static_cast<u8>(fg) | (static_cast<u8>(bg) << 4);
}

void putc(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\t') {
        cursor_x = (cursor_x + 4) & ~3;
    } else if (c == '\b') {
        if (cursor_x > 0) {
            cursor_x--;
            buffer[cursor_y * WIDTH + cursor_x] = make_entry(' ', current_color);
        }
    } else {
        buffer[cursor_y * WIDTH + cursor_x] = make_entry(c, current_color);
        cursor_x++;
    }

    if (cursor_x >= WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
    scroll();
    move_hw_cursor();
}

void write(const char* str) {
    while (*str) putc(*str++);
}

void write_hex(u64 value) {
    const char* digits = "0123456789ABCDEF";
    char out[17];
    out[16] = 0;
    for (int i = 15; i >= 0; i--) {
        out[i] = digits[value & 0xF];
        value >>= 4;
    }
    write("0x");
    write(out);
}

void write_dec(u64 value) {
    if (value == 0) { putc('0'); return; }
    char buf[21];
    int i = 20;
    buf[i--] = 0;
    while (value > 0) {
        buf[i--] = static_cast<char>('0' + (value % 10));
        value /= 10;
    }
    write(&buf[i + 1]);
}

} // namespace vga
