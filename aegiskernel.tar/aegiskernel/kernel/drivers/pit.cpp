#include "pit.h"
#include "ports.h"
#include "idt.h"
#include "pic.h"
#include "scheduler.h"

namespace pit {

namespace {
    constexpr u16 CHANNEL0 = 0x40;
    constexpr u16 COMMAND  = 0x43;
    constexpr u32 BASE_FREQ = 1193182;

    volatile u64 tick_count = 0;

    void irq_handler(idt::registers*) {
        tick_count++;
        scheduler::tick();
    }
}

void init(u32 frequency_hz) {
    u32 divisor = BASE_FREQ / frequency_hz;
    outb(COMMAND, 0x36); // channel 0, lo/hi byte, mode 3 (square wave), binary
    outb(CHANNEL0, static_cast<u8>(divisor & 0xFF));
    outb(CHANNEL0, static_cast<u8>((divisor >> 8) & 0xFF));

    idt::register_handler(32, irq_handler); // IRQ0
    pic_clear_mask(0);
}

u64 ticks() {
    return tick_count;
}

} // namespace pit
