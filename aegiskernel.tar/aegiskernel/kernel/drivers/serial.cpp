#include "serial.h"
#include "ports.h"

namespace serial {

namespace {
    constexpr u16 COM1 = 0x3F8;

    bool transmit_empty() {
        return (inb(COM1 + 5) & 0x20) != 0;
    }
}

void init() {
    outb(COM1 + 1, 0x00);    // disable interrupts
    outb(COM1 + 3, 0x80);    // enable DLAB
    outb(COM1 + 0, 0x03);    // divisor lo -> 38400 baud
    outb(COM1 + 1, 0x00);    // divisor hi
    outb(COM1 + 3, 0x03);    // 8N1, DLAB off
    outb(COM1 + 2, 0xC7);    // enable FIFO, clear, 14-byte threshold
    outb(COM1 + 4, 0x0B);    // IRQs enabled, RTS/DSR set
}

void putc(char c) {
    if (c == '\n') putc('\r');
    while (!transmit_empty()) { }
    outb(COM1, static_cast<u8>(c));
}

void write(const char* str) {
    while (*str) putc(*str++);
}

void write_hex(u64 value) {
    const char* digits = "0123456789ABCDEF";
    char out[17];
    out[16] = 0;
    for (int i = 15; i >= 0; i--) {
        out[i] = digits[value & 0xF];
        value >>= 4;
    }
    write("0x");
    write(out);
}

void write_dec(u64 value) {
    if (value == 0) { putc('0'); return; }
    char buf[21];
    int i = 20;
    buf[i--] = 0;
    while (value > 0) {
        buf[i--] = static_cast<char>('0' + (value % 10));
        value /= 10;
    }
    write(&buf[i + 1]);
}

} // namespace serial
