#include "scheduler.h"
#include "kmalloc.h"
#include "serial.h"

extern "C" void switch_context(u64* old_rsp_out, u64 new_rsp);
extern "C" void task_trampoline();

namespace scheduler {

namespace {
    task tasks[MAX_TASKS];
    int task_count = 0;
    int current = -1;
    bool started = false;

    // rsp of whichever context called into the scheduler for the very first
    // time (start()); used as the "old_rsp_out" slot for the boot context.
    u64 boot_rsp = 0;

    int next_ready(int from) {
        for (int i = 1; i <= task_count; i++) {
            int idx = (from + i) % task_count;
            if (tasks[idx].state == task_state::Ready ||
                tasks[idx].state == task_state::Running) {
                return idx;
            }
        }
        return -1;
    }
}

void init() {
    task_count = 0;
    current = -1;
    started = false;
}

int create_task(const char* name, task_entry_fn entry) {
    if (task_count >= MAX_TASKS) return -1;

    int id = task_count++;
    task& t = tasks[id];
    t.id = id;
    t.name = name;
    t.state = task_state::Ready;

    void* stack_mem = kmalloc::alloc(TASK_STACK_SIZE);
    t.stack_base = reinterpret_cast<u64>(stack_mem);
    u64 stack_top = t.stack_base + TASK_STACK_SIZE;

    // Build the initial frame consumed by switch_context's epilogue (see
    // context_switch.asm): r15..rbx then a return address.
    u64* sp = reinterpret_cast<u64*>(stack_top);
    sp -= 7;
    sp[0] = reinterpret_cast<u64>(entry);            // -> popped into r15
    sp[1] = 0;                                        // r14
    sp[2] = 0;                                        // r13
    sp[3] = 0;                                        // r12
    sp[4] = 0;                                        // rbp
    sp[5] = 0;                                        // rbx
    sp[6] = reinterpret_cast<u64>(task_trampoline);    // return address

    t.rsp = reinterpret_cast<u64>(sp);
    return id;
}

void start() {
    if (task_count == 0) return;
    current = 0;
    tasks[0].state = task_state::Running;
    started = true;
    serial::write("[sched] starting task: ");
    serial::write(tasks[0].name);
    serial::write("\n");
    switch_context(&boot_rsp, tasks[0].rsp);
    // never returns
}

void tick() {
    if (!started) return;

    int next = next_ready(current);
    if (next < 0 || next == current) return;

    task& cur = tasks[current];
    task& nxt = tasks[next];

    if (cur.state == task_state::Running) cur.state = task_state::Ready;
    nxt.state = task_state::Running;

    int prev = current;
    current = next;
    switch_context(&tasks[prev].rsp, tasks[next].rsp);
}

void yield() {
    tick();
}

void exit_current() {
    if (current < 0) return;
    tasks[current].state = task_state::Terminated;

    int next = next_ready(current);
    if (next < 0 || next == current) {
        serial::write("[sched] all tasks exited, halting\n");
        for (;;) asm volatile("cli; hlt");
    }

    int prev = current;
    tasks[next].state = task_state::Running;
    current = next;
    switch_context(&tasks[prev].rsp, tasks[next].rsp);
}

} // namespace scheduler

extern "C" void task_exit_trampoline() {
    scheduler::exit_current();
}
