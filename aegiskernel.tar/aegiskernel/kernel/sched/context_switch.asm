; ============================================================================
; aegiskernel - context switch + task entry trampoline
; ============================================================================

BITS 64
section .text

extern task_exit_trampoline

; void switch_context(u64* old_rsp_out, u64 new_rsp)
;   rdi = pointer to store the outgoing task's rsp
;   rsi = incoming task's rsp to switch to
global switch_context
switch_context:
    push rbx
    push rbp
    push r12
    push r13
    push r14
    push r15

    mov [rdi], rsp
    mov rsp, rsi

    pop r15
    pop r14
    pop r13
    pop r12
    pop rbp
    pop rbx
    ret

; Landed on via the `ret` above the very first time a task runs. Initial
; stacks are built by scheduler::create_task() so that r15 holds the task's
; entry function pointer at this point (see kernel/sched/scheduler.cpp).
global task_trampoline
task_trampoline:
    sti                     ; new tasks start with interrupts enabled
    call r15
    call task_exit_trampoline
.hang:
    hlt
    jmp .hang
