#include "kmalloc.h"
#include "pmm.h"

namespace kmalloc {

namespace {
    struct block_header {
        size_t size;       // usable size, excludes header
        bool free;
        block_header* next; // address-ordered, singly linked
    };

    constexpr size_t ALIGN = 16;
    constexpr size_t HEADER_SIZE = sizeof(block_header);

    // heap_max_pages caps total heap growth as a simple OOM guard; the real
    // ceiling is however many pages the PMM has left in the identity-mapped
    // 64 MiB window.
    uptr pages_used = 0;
    uptr max_pages = 0;
    block_header* first_block = nullptr;
    block_header* last_block = nullptr;

    inline size_t align_up(size_t n, size_t a) {
        return (n + a - 1) & ~(a - 1);
    }

    // Extend the heap by at least `min_bytes`. Physical pages from the PMM
    // are used directly as addresses - no vmm::map_page() call needed, since
    // the whole managed 64 MiB window is already identity-mapped by the
    // bootloader with 2 MiB pages. (Walking that via vmm::map_page would
    // misread a huge-page PD entry as a page-table pointer.)
    block_header* extend_heap(size_t min_bytes) {
        size_t needed = align_up(min_bytes + HEADER_SIZE, pmm::PAGE_SIZE);
        uptr page_count = needed / pmm::PAGE_SIZE;
        if (max_pages && pages_used + page_count > max_pages) return nullptr;

        uptr block_addr = pmm::alloc_pages(page_count);
        if (!block_addr) return nullptr;
        pages_used += page_count;

        auto* blk = reinterpret_cast<block_header*>(block_addr);
        blk->size = needed - HEADER_SIZE;
        blk->free = true;
        blk->next = nullptr;

        if (last_block) last_block->next = blk;
        else first_block = blk;
        last_block = blk;

        return blk;
    }

    void split_block(block_header* blk, size_t size) {
        size_t remaining = blk->size - size;
        if (remaining <= HEADER_SIZE + ALIGN) return; // not worth splitting

        auto* new_blk = reinterpret_cast<block_header*>(
            reinterpret_cast<u8*>(blk) + HEADER_SIZE + size);
        new_blk->size = remaining - HEADER_SIZE;
        new_blk->free = true;
        new_blk->next = blk->next;

        blk->size = size;
        blk->next = new_blk;
        if (last_block == blk) last_block = new_blk;
    }

    void coalesce() {
        for (block_header* b = first_block; b && b->next; ) {
            uptr b_end = reinterpret_cast<uptr>(b) + HEADER_SIZE + b->size;
            if (b->free && b->next->free && b_end == reinterpret_cast<uptr>(b->next)) {
                b->size += HEADER_SIZE + b->next->size;
                if (last_block == b->next) last_block = b;
                b->next = b->next->next;
                // re-check same block against its new next
            } else {
                b = b->next;
            }
        }
    }
}

void init(uptr max_heap_bytes) {
    max_pages = max_heap_bytes / pmm::PAGE_SIZE;
    pages_used = 0;
    first_block = nullptr;
    last_block = nullptr;
}

void* alloc(size_t size) {
    size = align_up(size, ALIGN);

    for (block_header* b = first_block; b; b = b->next) {
        if (b->free && b->size >= size) {
            split_block(b, size);
            b->free = false;
            return reinterpret_cast<u8*>(b) + HEADER_SIZE;
        }
    }

    block_header* fresh = extend_heap(size);
    if (!fresh) return nullptr;
    split_block(fresh, size);
    fresh->free = false;
    return reinterpret_cast<u8*>(fresh) + HEADER_SIZE;
}

void free(void* ptr) {
    if (!ptr) return;
    auto* blk = reinterpret_cast<block_header*>(reinterpret_cast<u8*>(ptr) - HEADER_SIZE);
    blk->free = true;
    coalesce();
}

} // namespace kmalloc

void* operator new(size_t size) { return kmalloc::alloc(size); }
void* operator new[](size_t size) { return kmalloc::alloc(size); }
void operator delete(void* ptr) noexcept { kmalloc::free(ptr); }
void operator delete[](void* ptr) noexcept { kmalloc::free(ptr); }
void operator delete(void* ptr, size_t) noexcept { kmalloc::free(ptr); }
void operator delete[](void* ptr, size_t) noexcept { kmalloc::free(ptr); }
