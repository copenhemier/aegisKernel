#include "vmm.h"
#include "pmm.h"

namespace vmm {

namespace {
    // Set up by boot/stage2.asm; reused rather than rebuilt.
    constexpr uptr PML4_PHYS = 0x10000;

    constexpr u64 ADDR_MASK = 0x000FFFFFFFFFF000ULL;

    inline u64* table_at(uptr phys) {
        // Identity-mapped region (0-64MiB), so phys == virt for page tables.
        return reinterpret_cast<u64*>(phys);
    }

    inline uptr pml4_index(uptr v) { return (v >> 39) & 0x1FF; }
    inline uptr pdpt_index(uptr v) { return (v >> 30) & 0x1FF; }
    inline uptr pd_index(uptr v)   { return (v >> 21) & 0x1FF; }
    inline uptr pt_index(uptr v)   { return (v >> 12) & 0x1FF; }

    // Returns the next-level table's physical base, allocating+zeroing a
    // fresh page table if the entry isn't present yet.
    u64* next_level(u64* table, uptr index, u64 flags) {
        if (!(table[index] & PAGE_PRESENT)) {
            uptr new_table = pmm::alloc_page();
            u64* zeroed = table_at(new_table);
            for (int i = 0; i < 512; i++) zeroed[i] = 0;
            table[index] = (new_table & ADDR_MASK) | flags | PAGE_PRESENT;
        }
        return table_at(table[index] & ADDR_MASK);
    }
}

void init() {
    // Page tables already active from the bootloader hand-off; nothing to do
    // beyond recording the base, which is a compile-time constant here.
}

void map_page(uptr virt_addr, uptr phys_addr, u64 flags) {
    virt_addr &= ~(pmm::PAGE_SIZE - 1);
    phys_addr &= ~(pmm::PAGE_SIZE - 1);

    u64* pml4 = table_at(PML4_PHYS);
    u64* pdpt = next_level(pml4, pml4_index(virt_addr), PAGE_WRITABLE);
    u64* pd   = next_level(pdpt, pdpt_index(virt_addr), PAGE_WRITABLE);
    u64* pt   = next_level(pd,   pd_index(virt_addr),   PAGE_WRITABLE);

    pt[pt_index(virt_addr)] = (phys_addr & ADDR_MASK) | flags;

    asm volatile("invlpg (%0)" : : "r"(virt_addr) : "memory");
}

void unmap_page(uptr virt_addr) {
    virt_addr &= ~(pmm::PAGE_SIZE - 1);
    u64* pml4 = table_at(PML4_PHYS);

    u64 pml4e = pml4[pml4_index(virt_addr)];
    if (!(pml4e & PAGE_PRESENT)) return;
    u64* pdpt = table_at(pml4e & ADDR_MASK);

    u64 pdpte = pdpt[pdpt_index(virt_addr)];
    if (!(pdpte & PAGE_PRESENT)) return;
    u64* pd = table_at(pdpte & ADDR_MASK);

    u64 pde = pd[pd_index(virt_addr)];
    if (!(pde & PAGE_PRESENT)) return;
    u64* pt = table_at(pde & ADDR_MASK);

    pt[pt_index(virt_addr)] = 0;
    asm volatile("invlpg (%0)" : : "r"(virt_addr) : "memory");
}

uptr translate(uptr virt_addr) {
    u64* pml4 = table_at(PML4_PHYS);
    u64 pml4e = pml4[pml4_index(virt_addr)];
    if (!(pml4e & PAGE_PRESENT)) return 0;
    u64* pdpt = table_at(pml4e & ADDR_MASK);

    u64 pdpte = pdpt[pdpt_index(virt_addr)];
    if (!(pdpte & PAGE_PRESENT)) return 0;
    if (pdpte & (1ULL << 7)) return (pdpte & ADDR_MASK) | (virt_addr & 0x3FFFFFFF); // 1G page
    u64* pd = table_at(pdpte & ADDR_MASK);

    u64 pde = pd[pd_index(virt_addr)];
    if (!(pde & PAGE_PRESENT)) return 0;
    if (pde & (1ULL << 7)) return (pde & ADDR_MASK) | (virt_addr & 0x1FFFFF); // 2M page
    u64* pt = table_at(pde & ADDR_MASK);

    u64 pte = pt[pt_index(virt_addr)];
    if (!(pte & PAGE_PRESENT)) return 0;
    return (pte & ADDR_MASK) | (virt_addr & 0xFFF);
}

} // namespace vmm
