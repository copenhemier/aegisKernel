#include "pmm.h"

namespace pmm {

namespace {
    // Matches IDENTITY_MAP_MB in boot/stage2.asm. VMM extends mapping later;
    // the PMM's own bookkeeping region is capped to what's guaranteed mapped
    // at boot time.
    constexpr uptr MANAGED_MB = 64;
    constexpr uptr MANAGED_BYTES = MANAGED_MB * 1024 * 1024;
    constexpr uptr TOTAL_PAGES = MANAGED_BYTES / PAGE_SIZE; // 16384
    constexpr uptr BITMAP_BYTES = TOTAL_PAGES / 8;           // 2048

    u8 bitmap[BITMAP_BYTES];
    u64 used_count = 0;

    inline bool test_bit(uptr page_idx) {
        return (bitmap[page_idx / 8] & (1 << (page_idx % 8))) != 0;
    }
    inline void set_bit(uptr page_idx) {
        bitmap[page_idx / 8] |= static_cast<u8>(1 << (page_idx % 8));
    }
    inline void clear_bit(uptr page_idx) {
        bitmap[page_idx / 8] &= static_cast<u8>(~(1 << (page_idx % 8)));
    }

    void mark_used_range(uptr start, uptr end) {
        uptr first = start / PAGE_SIZE;
        uptr last = (end + PAGE_SIZE - 1) / PAGE_SIZE;
        if (last > TOTAL_PAGES) last = TOTAL_PAGES;
        for (uptr p = first; p < last; p++) {
            if (!test_bit(p)) { set_bit(p); used_count++; }
        }
    }
}

void init(const boot_info* info, uptr kernel_end) {
    for (auto& b : bitmap) b = 0;
    used_count = 0;

    // Reserve the low 1 MiB unconditionally (real-mode IVT/BDA, bootloader,
    // page tables, boot_info/E820 buffer).
    mark_used_range(0, 0x100000);

    // Reserve the kernel image itself, plus this bitmap's own storage.
    mark_used_range(0x100000, kernel_end);

    // Cross-check E820: anything non-usable inside our managed window gets
    // reserved too, in case the low-memory map isn't uniformly free RAM.
    for (u32 i = 0; i < info->mmap_count; i++) {
        const e820_entry& e = info->entries[i];
        if (e.type == E820_USABLE) continue;
        if (e.base >= MANAGED_BYTES) continue;
        u64 end = e.base + e.length;
        if (end > MANAGED_BYTES) end = MANAGED_BYTES;
        mark_used_range(static_cast<uptr>(e.base), static_cast<uptr>(end));
    }
}

uptr alloc_page() {
    for (uptr p = 0; p < TOTAL_PAGES; p++) {
        if (!test_bit(p)) {
            set_bit(p);
            used_count++;
            return p * PAGE_SIZE;
        }
    }
    return 0; // out of memory
}

uptr alloc_pages(uptr count) {
    if (count == 0) return 0;
    uptr run_start = 0;
    uptr run_len = 0;

    for (uptr p = 0; p < TOTAL_PAGES; p++) {
        if (!test_bit(p)) {
            if (run_len == 0) run_start = p;
            run_len++;
            if (run_len == count) {
                for (uptr q = run_start; q < run_start + count; q++) {
                    set_bit(q);
                    used_count++;
                }
                return run_start * PAGE_SIZE;
            }
        } else {
            run_len = 0;
        }
    }
    return 0;
}

void free_page(uptr addr) {
    uptr p = addr / PAGE_SIZE;
    if (p >= TOTAL_PAGES) return;
    if (test_bit(p)) {
        clear_bit(p);
        used_count--;
    }
}

void free_pages(uptr addr, uptr count) {
    uptr start = addr / PAGE_SIZE;
    for (uptr p = start; p < start + count && p < TOTAL_PAGES; p++) {
        if (test_bit(p)) {
            clear_bit(p);
            used_count--;
        }
    }
}

u64 total_pages() { return TOTAL_PAGES; }
u64 used_pages()  { return used_count; }
u64 free_pages_count() { return TOTAL_PAGES - used_count; }

} // namespace pmm
