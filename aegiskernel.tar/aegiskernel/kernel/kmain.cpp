// ============================================================================
// aegiskernel - unity build root
// ============================================================================
// Single translation unit for the whole kernel core, matching the
// single-TU/zero-dependency style used across nullroot projects. Assembly
// files (entry.asm, isr_stubs.asm, context_switch.asm) are assembled and
// linked separately since NASM can't participate in a C++ unity build.
// ============================================================================

#include "vga.h"
#include "serial.h"
#include "ports.h"
#include "gdt.h"
#include "idt.h"
#include "pic.h"
#include "pit.h"
#include "keyboard.h"
#include "pmm.h"
#include "vmm.h"
#include "kmalloc.h"
#include "scheduler.h"
#include "boot_info.h"

#include "drivers/vga.cpp"
#include "drivers/serial.cpp"
#include "drivers/pit.cpp"
#include "drivers/keyboard.cpp"
#include "gdt.cpp"
#include "interrupts/pic.cpp"
#include "interrupts/idt.cpp"
#include "mm/pmm.cpp"
#include "mm/vmm.cpp"
#include "mm/kmalloc.cpp"
#include "sched/scheduler.cpp"

extern "C" char __kernel_end;

namespace {

void print_banner() {
    vga::set_color(vga::Color::LightGreen, vga::Color::Black);
    vga::write("aegiskernel v0.1\n");
    vga::set_color(vga::Color::LightGrey, vga::Color::Black);

    serial::write("========================================\n");
    serial::write(" aegiskernel v0.1 booting\n");
    serial::write("========================================\n");
}

void print_meminfo() {
    serial::write("[mm] total pages: "); serial::write_dec(pmm::total_pages());
    serial::write(" used: "); serial::write_dec(pmm::used_pages());
    serial::write(" free: "); serial::write_dec(pmm::free_pages_count());
    serial::write("\n");

    vga::write("mem: ");
    vga::write_dec(pmm::free_pages_count() * pmm::PAGE_SIZE / 1024);
    vga::write(" KiB free of ");
    vga::write_dec(pmm::total_pages() * pmm::PAGE_SIZE / 1024);
    vga::write(" KiB managed\n");
}

// ---- demo kernel threads proving the scheduler/keyboard/vga are alive ----

void task_heartbeat() {
    u64 n = 0;
    for (;;) {
        serial::write("[heartbeat] tick "); serial::write_dec(n++); serial::write("\n");
        for (volatile u64 i = 0; i < 5000000; i++) { }
        scheduler::yield();
    }
}

void task_shell() {
    vga::write("\ntype something (kernel-mode PS/2 echo test):\n> ");
    for (;;) {
        char c = keyboard::read_char();
        if (c == '\n') {
            vga::putc('\n');
            vga::write("> ");
        } else {
            vga::putc(c);
        }
    }
}

} // namespace

extern "C" void kmain(boot_info* info) {
    serial::init();
    vga::init();
    print_banner();

    gdt::init();
    serial::write("[boot] GDT/TSS loaded\n");

    idt::init();
    pic_remap();
    serial::write("[boot] IDT + PIC remapped (IRQ0-15 -> vec 32-47)\n");

    uptr kernel_end = reinterpret_cast<uptr>(&__kernel_end);
    pmm::init(info, kernel_end);
    serial::write("[boot] PMM initialized ("); serial::write_dec(info->mmap_count);
    serial::write(" E820 entries)\n");

    vmm::init();
    serial::write("[boot] VMM initialized (reusing bootloader identity map)\n");

    kmalloc::init(48 * 1024 * 1024); // cap heap growth well under the 64MiB window
    serial::write("[boot] kernel heap online\n");

    print_meminfo();

    pit::init(100); // 100 Hz scheduler tick
    keyboard::init();
    serial::write("[boot] PIT + keyboard IRQs enabled\n");

    asm volatile("sti");

    scheduler::init();
    scheduler::create_task("heartbeat", task_heartbeat);
    scheduler::create_task("shell", task_shell);
    serial::write("[boot] handing off to scheduler\n\n");

    scheduler::start();

    // unreachable
    for (;;) asm volatile("hlt");
}
