; ============================================================================
; aegiskernel - Stage 2 Bootloader
; ============================================================================
; Loaded by stage1 at 0x0000:0x8000 (real mode). Responsibilities:
;   1. Enable A20 line
;   2. Query BIOS E820 memory map -> store at BOOT_INFO_ADDR
;   3. Load the kernel image from disk into a low real-mode-reachable buffer
;   4. Enter 32-bit protected mode (flat GDT)
;   5. Copy the kernel up to its link address (1 MiB)
;   6. Build minimal identity-mapped page tables, enter 64-bit long mode
;   7. Jump to the kernel entry point with a boot_info pointer in RDI
;
; Memory map used by this stage (all physical/linear, low memory):
;   0x00008000 - 0x0000C000   stage2 itself (16 KiB max)
;   0x0000C000 - 0x0000D000   boot_info header + E820 entries
;   0x00010000 - 0x00013000   PML4 / PDPT / PD (identity map, 2 MiB pages)
;   0x00020000 - 0x00060000   real-mode kernel load buffer (256 KiB max)
;   0x00100000                final kernel location (linked address)
; ============================================================================

BITS 16
ORG 0x8000

BOOT_INFO_ADDR    equ 0xC000
PML4_ADDR         equ 0x10000
PDPT_ADDR         equ 0x11000
PD_ADDR           equ 0x12000
KERNEL_BUF_SEG    equ 0x2000
KERNEL_BUF_LIN    equ 0x20000
KERNEL_LOAD_ADDR  equ 0x00100000
KERNEL_START_LBA  equ 33          ; sector after stage1(1) + stage2(32)
KERNEL_SECTORS    equ 512         ; 256 KiB max kernel image (v1 ceiling)
IDENTITY_MAP_MB   equ 64          ; identity-map first 64 MiB

stage2_start:
    mov [boot_drive], dl    ; DL still holds the BIOS boot drive from stage1's jmp

    mov si, msg_stage2
    call print_string

    call enable_a20
    mov si, msg_a20
    call print_string

    call get_memory_map
    mov si, msg_mmap
    call print_string

    call load_kernel
    mov si, msg_kernel_loaded
    call print_string

    call enter_protected_mode
    ; does not return

halt:
    cli
.hang:
    hlt
    jmp .hang

; ----------------------------------------------------------------------
; Fast A20 gate via System Control Port A (0x92). Works on QEMU/most BIOS.
; ----------------------------------------------------------------------
enable_a20:
    in al, 0x92
    test al, 2
    jnz .done
    or al, 2
    and al, 0xFE
    out 0x92, al
.done:
    ret

; ----------------------------------------------------------------------
; BIOS INT 15h, EAX=E820h memory map -> BOOT_INFO_ADDR
; Layout: [u32 count][u32 reserved][entries...] (24 bytes/entry)
; ----------------------------------------------------------------------
get_memory_map:
    pusha
    mov edi, BOOT_INFO_ADDR + 8      ; leave room for header
    xor ebp, ebp                     ; entry count
    xor ebx, ebx                     ; continuation value
    mov edx, 0x534D4150               ; "SMAP"

.loop:
    mov eax, 0xE820
    mov ecx, 24
    int 0x15
    jc .done                         ; carry = end of list (or error)
    mov edx, 0x534D4150               ; some BIOSes clobber edx
    cmp eax, 0x534D4150
    jne .done

    test ebx, ebx
    jz .last_entry

    add edi, 24
    inc ebp
    jmp .loop

.last_entry:
    inc ebp
    jmp .store_count

.done:
.store_count:
    mov edi, BOOT_INFO_ADDR
    mov [edi], ebp
    mov dword [edi + 4], 0

    popa
    ret

; ----------------------------------------------------------------------
; Load kernel image from disk (LBA KERNEL_START_LBA) into KERNEL_BUF_LIN,
; in CHUNK_SECTORS-sized chunks - SeaBIOS (and some real BIOSes) reject
; INT13h AH=42h reads larger than ~127 sectors per call.
; ----------------------------------------------------------------------
CHUNK_SECTORS equ 64

load_kernel:
    pusha
    mov word [chunk_remaining], KERNEL_SECTORS
    mov word [chunk_lba_lo], KERNEL_START_LBA
    mov word [chunk_seg], KERNEL_BUF_SEG

.chunk_loop:
    mov ax, [chunk_remaining]
    cmp ax, 0
    je .done

    mov cx, CHUNK_SECTORS
    cmp ax, cx
    jae .use_full_chunk
    mov cx, ax
.use_full_chunk:
    mov [kernel_dap_sectors], cx

    mov ax, [chunk_seg]
    mov [kernel_dap_seg], ax

    mov ax, [chunk_lba_lo]
    mov [kernel_dap_lba], ax

    mov si, kernel_dap
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc .disk_error

    ; advance: buffer segment += (sectors_read * 512) / 16 ; lba += sectors_read
    mov ax, [kernel_dap_sectors]
    sub [chunk_remaining], ax
    add [chunk_lba_lo], ax
    shl ax, 5              ; sectors * 512 / 16 = sectors * 32
    add [chunk_seg], ax

    jmp .chunk_loop

.done:
    popa
    ret
.disk_error:
    mov si, msg_kernel_err
    call print_string
    jmp halt

chunk_remaining: dw 0
chunk_lba_lo:    dw 0
chunk_seg:       dw 0

; ----------------------------------------------------------------------
print_string:
    pusha
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    mov bh, 0x00
    int 0x10
    jmp .loop
.done:
    popa
    ret

; ----------------------------------------------------------------------
; Enter 32-bit protected mode with a flat GDT, then hand off to pm_main.
; ----------------------------------------------------------------------
enter_protected_mode:
    cli
    lgdt [gdt32_descriptor]

    mov eax, cr0
    or eax, 1
    mov cr0, eax

    jmp CODE32_SEL:pm_main

BITS 32
pm_main:
    mov ax, DATA32_SEL
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x90000

    ; ---- Copy kernel image from real-mode buffer up to 1 MiB ----
    mov esi, KERNEL_BUF_LIN
    mov edi, KERNEL_LOAD_ADDR
    mov ecx, (KERNEL_SECTORS * 512) / 4
    rep movsd

    ; ---- Build identity-mapped page tables (2 MiB pages) ----
    call build_page_tables

    ; ---- Enable PAE ----
    mov eax, cr4
    or eax, (1 << 5)          ; CR4.PAE
    mov cr4, eax

    ; ---- Load CR3 with PML4 base ----
    mov eax, PML4_ADDR
    mov cr3, eax

    ; ---- Enable long mode (EFER.LME) ----
    mov ecx, 0xC0000080        ; IA32_EFER
    rdmsr
    or eax, (1 << 8)           ; LME
    wrmsr

    ; ---- Enable paging (CR0.PG) -> now in IA-32e compatibility mode ----
    mov eax, cr0
    or eax, (1 << 31)
    mov cr0, eax

    jmp CODE64_SEL:lm_main

; ----------------------------------------------------------------------
; Build PML4[0] -> PDPT[0] -> PD[0..N] identity-mapping 0..IDENTITY_MAP_MB
; using 2 MiB pages. All tables pre-zeroed.
; ----------------------------------------------------------------------
build_page_tables:
    pushad

    mov edi, PML4_ADDR
    mov ecx, 4096 / 4
    xor eax, eax
    rep stosd

    mov edi, PDPT_ADDR
    mov ecx, 4096 / 4
    xor eax, eax
    rep stosd

    mov edi, PD_ADDR
    mov ecx, 4096 / 4
    xor eax, eax
    rep stosd

    ; PML4[0] = PDPT_ADDR | present | writable
    mov eax, PDPT_ADDR
    or eax, 0x3
    mov [PML4_ADDR], eax

    ; PDPT[0] = PD_ADDR | present | writable
    mov eax, PD_ADDR
    or eax, 0x3
    mov [PDPT_ADDR], eax

    ; PD[0..N] = i * 2MiB | present | writable | page-size(2MiB)
    mov ecx, IDENTITY_MAP_MB / 2   ; number of 2 MiB pages
    xor ebx, ebx                   ; index
.fill_pd:
    mov eax, ebx
    shl eax, 21                    ; * 2 MiB
    or eax, 0x83                   ; present | writable | PS(2MiB)
    mov [PD_ADDR + ebx*8], eax
    inc ebx
    loop .fill_pd

    popad
    ret

BITS 64
lm_main:
    mov ax, DATA64_SEL
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov rsp, 0x90000

    mov rdi, BOOT_INFO_ADDR         ; arg0 = boot_info* for kernel entry
    mov rax, KERNEL_LOAD_ADDR
    jmp rax

BITS 16
; ----------------------------------------------------------------------
boot_drive: db 0

kernel_dap:
    db 0x10
    db 0
kernel_dap_sectors:
    dw 0
    dw 0x0000
kernel_dap_seg:
    dw 0
kernel_dap_lba:
    dq 0

msg_stage2        db "aegiskernel: stage2 running", 13, 10, 0
msg_a20           db "aegiskernel: A20 enabled", 13, 10, 0
msg_mmap          db "aegiskernel: E820 map acquired", 13, 10, 0
msg_kernel_loaded db "aegiskernel: kernel image loaded", 13, 10, 0
msg_kernel_err    db "aegiskernel: FATAL kernel load failed", 13, 10, 0

; ----------------------------------------------------------------------
; GDT: null, 32-bit flat code/data, 64-bit flat code/data
; ----------------------------------------------------------------------
align 8
gdt32_start:
    dq 0x0000000000000000              ; null

gdt32_code32:
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00           ; base=0 limit=4G, exec/read, 32-bit

gdt32_data32:
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00           ; base=0 limit=4G, read/write

gdt32_code64:
    dw 0x0000, 0x0000
    db 0x00, 0x9A, 0x20, 0x00           ; L-bit set, long mode code segment

gdt32_data64:
    dw 0x0000, 0x0000
    db 0x00, 0x92, 0x00, 0x00           ; long mode data segment
gdt32_end:

gdt32_descriptor:
    dw gdt32_end - gdt32_start - 1
    dd gdt32_start

CODE32_SEL equ gdt32_code32 - gdt32_start
DATA32_SEL equ gdt32_data32 - gdt32_start
CODE64_SEL equ gdt32_code64 - gdt32_start
DATA64_SEL equ gdt32_data64 - gdt32_start

times 16384 - ($ - $$) db 0     ; pad stage2 to exactly 32 sectors (16 KiB)
