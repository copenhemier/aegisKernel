; ============================================================================
; aegiskernel - Stage 1 Bootloader (MBR)
; ============================================================================
; Loaded by BIOS at 0x7C00. Must fit in 512 bytes with 0x55AA signature.
; Job: enable disk extensions, load Stage 2 from sectors 2..N into memory
;      at 0x0000:0x8000, then jump to it.
; ============================================================================

BITS 16
ORG 0x7C00

STAGE2_LOAD_SEG   equ 0x0000
STAGE2_LOAD_OFF   equ 0x8000
STAGE2_SECTORS    equ 32          ; 16 KiB reserved for stage2 (grows with features)

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov [boot_drive], dl        ; BIOS passes boot drive number in dl

    mov si, msg_stage1
    call print_string

    ; ---- Check for INT13h extensions (LBA read support) ----
    mov ah, 0x41
    mov bx, 0x55AA
    mov dl, [boot_drive]
    int 0x13
    jc .no_ext
    cmp bx, 0xAA55
    jne .no_ext

    ; ---- Load stage2 via LBA extended read ----
    mov si, dap
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc disk_error

    mov si, msg_ok
    call print_string

    jmp STAGE2_LOAD_SEG:STAGE2_LOAD_OFF

.no_ext:
    mov si, msg_no_ext
    call print_string
    jmp halt

disk_error:
    mov si, msg_disk_err
    call print_string
    jmp halt

halt:
    cli
.hang:
    hlt
    jmp .hang

; ----------------------------------------------------------------------
print_string:                  ; si -> null-terminated string
    pusha
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    mov bh, 0x00
    int 0x10
    jmp .loop
.done:
    popa
    ret

; ----------------------------------------------------------------------
boot_drive:  db 0

dap:                            ; Disk Address Packet for INT13h ext read
    db 0x10                     ; size of DAP
    db 0                        ; reserved
    dw STAGE2_SECTORS           ; sectors to read
    dw STAGE2_LOAD_OFF          ; offset
    dw STAGE2_LOAD_SEG          ; segment
    dq 1                        ; starting LBA (sector 1 = second sector, 0-indexed)

msg_stage1   db "aegiskernel: stage1 boot", 13, 10, 0
msg_ok       db "aegiskernel: stage2 loaded", 13, 10, 0
msg_no_ext   db "aegiskernel: FATAL no INT13h ext", 13, 10, 0
msg_disk_err db "aegiskernel: FATAL disk read error", 13, 10, 0

times 510 - ($ - $$) db 0
dw 0xAA55
