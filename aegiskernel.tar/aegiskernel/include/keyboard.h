#pragma once
#include "types.h"

namespace keyboard {

void init();
bool has_char();
char read_char();   // blocks (polls) until a char is available

} // namespace keyboard
