#pragma once
#include "types.h"

void pic_remap();
void pic_send_eoi(u8 irq);
void pic_set_mask(u8 irq);
void pic_clear_mask(u8 irq);
