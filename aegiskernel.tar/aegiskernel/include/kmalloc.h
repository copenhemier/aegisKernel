#pragma once
#include "types.h"

namespace kmalloc {

void init(uptr max_heap_bytes);
void* alloc(size_t size);
void free(void* ptr);

} // namespace kmalloc

void* operator new(size_t size);
void* operator new[](size_t size);
void operator delete(void* ptr) noexcept;
void operator delete[](void* ptr) noexcept;
void operator delete(void* ptr, size_t) noexcept;
void operator delete[](void* ptr, size_t) noexcept;
