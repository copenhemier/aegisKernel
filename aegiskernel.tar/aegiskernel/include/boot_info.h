#pragma once
#include "types.h"

// Matches the E820 memory map layout written by boot/stage2.asm at
// BOOT_INFO_ADDR (0xC000). Do not reorder without updating the bootloader.
struct e820_entry {
    u64 base;
    u64 length;
    u32 type;       // 1 = usable RAM, others = reserved/ACPI/NVS/bad
    u32 acpi_ext;
} __attribute__((packed));

enum e820_type : u32 {
    E820_USABLE   = 1,
    E820_RESERVED = 2,
    E820_ACPI_RECLAIM = 3,
    E820_ACPI_NVS = 4,
    E820_BAD      = 5,
};

struct boot_info {
    u32 mmap_count;
    u32 reserved;
    e820_entry entries[]; // flexible array, mmap_count entries follow
} __attribute__((packed));
