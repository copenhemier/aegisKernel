#pragma once
#include "types.h"

namespace pit {

void init(u32 frequency_hz);
u64 ticks();

} // namespace pit
