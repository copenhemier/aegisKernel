#pragma once
#include "types.h"

namespace serial {

void init();
void putc(char c);
void write(const char* str);
void write_hex(u64 value);
void write_dec(u64 value);

} // namespace serial
