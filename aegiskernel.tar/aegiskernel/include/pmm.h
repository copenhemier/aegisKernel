#pragma once
#include "types.h"
#include "boot_info.h"

namespace pmm {

constexpr uptr PAGE_SIZE = 4096;

void init(const boot_info* info, uptr kernel_end);
uptr alloc_page();          // returns physical address, 0 on failure
uptr alloc_pages(uptr count); // contiguous run, 0 on failure
void free_page(uptr addr);
void free_pages(uptr addr, uptr count);
u64 total_pages();
u64 used_pages();
u64 free_pages_count();

} // namespace pmm
