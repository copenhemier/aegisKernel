#pragma once
#include "types.h"

namespace gdt {

struct __attribute__((packed)) entry {
    u16 limit_low;
    u16 base_low;
    u8  base_mid;
    u8  access;
    u8  granularity;
    u8  base_high;
};

struct __attribute__((packed)) tss_entry {
    u32 reserved0;
    u64 rsp0;
    u64 rsp1;
    u64 rsp2;
    u64 reserved1;
    u64 ist[7];
    u64 reserved2;
    u16 reserved3;
    u16 iomap_base;
};

struct __attribute__((packed)) descriptor_ptr {
    u16 limit;
    u64 base;
};

constexpr u16 KERNEL_CODE_SEL = 0x08;
constexpr u16 KERNEL_DATA_SEL = 0x10;
constexpr u16 TSS_SEL         = 0x18;

void init();
void set_ist1(uptr stack_top); // double-fault / NMI safe stack

} // namespace gdt
