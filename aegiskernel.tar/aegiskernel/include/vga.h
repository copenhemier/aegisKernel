#pragma once
#include "types.h"

namespace vga {

enum class Color : u8 {
    Black = 0, Blue, Green, Cyan, Red, Magenta, Brown, LightGrey,
    DarkGrey, LightBlue, LightGreen, LightCyan, LightRed, LightMagenta,
    Yellow, White,
};

void init();
void clear();
void set_color(Color fg, Color bg);
void putc(char c);
void write(const char* str);
void write_hex(u64 value);
void write_dec(u64 value);

} // namespace vga
