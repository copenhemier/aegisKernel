#pragma once
#include "types.h"

namespace scheduler {

using task_entry_fn = void (*)();

enum class task_state : u8 { Ready, Running, Blocked, Terminated };

constexpr int MAX_TASKS = 32;
constexpr uptr TASK_STACK_SIZE = 16 * 1024;

struct task {
    u64 rsp;
    u64 stack_base;
    task_state state;
    const char* name;
    int id;
};

void init();
int  create_task(const char* name, task_entry_fn entry);
void start();          // never returns - begins running task 0
void tick();           // called from the PIT IRQ handler
void yield();          // cooperative context switch
void exit_current();   // terminate the currently running task

} // namespace scheduler
