#pragma once
// aegiskernel - freestanding type definitions.
// We do rely on the compiler-provided <stdint.h>/<stddef.h> since freestanding
// GCC ships these as pure header-only definitions with no libc linkage
// required. No other headers are used anywhere in the kernel.
#include <stdint.h>
#include <stddef.h>

using u8  = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using i8  = int8_t;
using i16 = int16_t;
using i32 = int32_t;
using i64 = int64_t;
using uptr = uintptr_t;

static_assert(sizeof(void*) == 8, "aegiskernel requires a 64-bit target");
