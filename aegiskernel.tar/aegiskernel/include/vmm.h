#pragma once
#include "types.h"

namespace vmm {

constexpr u64 PAGE_PRESENT  = 1ULL << 0;
constexpr u64 PAGE_WRITABLE = 1ULL << 1;
constexpr u64 PAGE_USER     = 1ULL << 2; // unused (ring0-only kernel) but modeled

void init();
// Maps a 4 KiB page. NOTE: virt_addr must NOT fall inside the bootloader's
// 0-64MiB identity-mapped region (see boot/stage2.asm, IDENTITY_MAP_MB) -
// that range is covered by 2 MiB PD-level huge pages, and walking into a
// huge-page PD entry here would misinterpret its physical frame as a
// page-table pointer. This is for mapping virtual addresses above that
// window (e.g. future higher-half or MMIO mappings).
void map_page(uptr virt_addr, uptr phys_addr, u64 flags = PAGE_PRESENT | PAGE_WRITABLE);
void unmap_page(uptr virt_addr);
uptr translate(uptr virt_addr); // returns physical addr or 0 if unmapped

} // namespace vmm
