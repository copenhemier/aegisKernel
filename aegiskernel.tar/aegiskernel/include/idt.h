#pragma once
#include "types.h"

namespace idt {

// Register layout pushed by the common ISR/IRQ stub, matches isr_stubs.asm.
struct __attribute__((packed)) registers {
    u64 r15, r14, r13, r12, r11, r10, r9, r8;
    u64 rbp, rdi, rsi, rdx, rcx, rbx, rax;
    u64 vector;
    u64 error_code;
    u64 rip, cs, rflags, rsp, ss; // pushed by CPU
};

using handler_fn = void (*)(registers*);

void init();
void register_handler(u8 vector, handler_fn fn);

} // namespace idt
