# AegisKernel

A custom x86-64 kernel with its own custom bootloader — no GRUB, no
multiboot, no libc. Written by hand from real mode up through long mode,
with a physical/virtual memory manager, a preemptive round-robin scheduler,
and a PS/2 keyboard driver.

```
aegiskernel v0.1
mem: 64416 KiB free of 65536 KiB managed

type something (kernel-mode PS/2 echo test):
>
```

## What's actually implemented

- **Custom two-stage bootloader** (`boot/stage1.asm`, `boot/stage2.asm`) —
  MBR → real mode → A20 gate → BIOS E820 memory map → protected mode → 4-level
  page tables → long mode, all hand-written, no GRUB/multiboot involved.
- **GDT + TSS** (`kernel/gdt.cpp`) — flat 64-bit code/data segments plus a TSS
  with an IST entry reserved for double faults.
- **IDT + ISR/IRQ stubs** (`kernel/interrupts/`) — all 32 CPU exceptions and
  16 remapped hardware IRQs, common dispatch trampoline in assembly, C++
  handler table.
- **8259 PIC remap** — IRQs moved off the CPU's own exception vectors (0–31)
  onto 32–47.
- **Physical memory manager** (`kernel/mm/pmm.cpp`) — bitmap allocator over
  the bootloader's identity-mapped 64 MiB window, reserves low memory, the
  kernel image, and any E820-reported non-usable ranges.
- **Virtual memory manager** (`kernel/mm/vmm.cpp`) — full PML4→PDPT→PD→PT
  walker for mapping pages outside the boot-time identity-mapped region.
- **Kernel heap** (`kernel/mm/kmalloc.cpp`) — address-ordered free-list
  allocator with splitting/coalescing, backing `new`/`delete`.
- **Preemptive round-robin scheduler** (`kernel/sched/`) — real context
  switches via hand-written assembly, driven off a 100 Hz PIT tick.
- **Drivers** — VGA text mode (scrolling, color), 16550 UART/serial (doubles
  as a boot-log/debug channel), PIT, PS/2 keyboard (scancode set 1, ring
  buffer).

Everything is ring 0 — there's no ring 3, no syscalls, no user processes.
"Tasks" are cooperative/preemptible kernel threads sharing one address space.

## Architecture notes

- The bootloader identity-maps the first 64 MiB with 2 MiB huge pages before
  jumping into the kernel. The PMM and kernel heap both live inside that
  window and use physical addresses directly as virtual ones. `vmm::map_page`
  is there for future use (higher-half kernel, MMIO, user mappings) but must
  only be used *outside* that 64 MiB window — walking into a huge-page PD
  entry would misinterpret it as a page-table pointer. This is documented at
  the call site.
- Kernel core (everything under `kernel/*.cpp`) is a **unity build** —
  `kernel/kmain.cpp` `#include`s every other `.cpp` file and is the only
  translation unit passed to the compiler. This matches the single-TU,
  zero-dependency style used elsewhere in nullroot projects. Assembly files
  (`entry.asm`, `isr_stubs.asm`, `context_switch.asm`) are necessarily
  assembled and linked separately.
- No libc, no libstdc++. The only headers pulled in are the freestanding
  `<stdint.h>`/`<stddef.h>` that ship with GCC itself (not glibc). `operator
  new`/`delete` are implemented directly on top of `kmalloc`.

## Building

Requires `nasm`, `gcc`/`g++` (targeting x86-64), `binutils` (`ld`,
`objcopy`), and `qemu-system-x86` for testing. On Debian/Ubuntu:

```sh
sudo apt install nasm gcc g++ binutils qemu-system-x86
```

```sh
make          # builds build/aegiskernel.img
make run      # boot it in QEMU with a display + serial on stdio
make test     # headless boot, 8s timeout, serial to stdout
make clean
```

`make run-debug` adds `-d int,cpu_reset` if something goes sideways at the
CPU level.

## Booting on real hardware

`build/aegiskernel.img` is a raw disk image — `dd` it to a USB stick and boot
it via legacy BIOS (not UEFI; there's no UEFI bootloader here):

```sh
sudo dd if=build/aegiskernel.img of=/dev/sdX bs=4M status=progress
```

**This has only been tested in QEMU.** Real hardware has BIOSes with
different quirks (some older or unusual ones may not support the INT13h
extensions this bootloader requires, or may cap extended reads at a
different sector count than SeaBIOS does). Treat real-hardware boot as
untested territory — try it on something you don't mind reinstalling.

## Known limitations / where this stops being "done"

- Kernel image is capped at 256 KiB by the bootloader's fixed read size
  (`KERNEL_SECTORS` in `boot/stage2.asm`). Bump that constant (and the
  matching `KERNEL_MAX_BYTES` in the `Makefile`) if the kernel grows past it.
- PMM/heap are capped to the first 64 MiB of physical RAM — the identity-map
  window the bootloader sets up. Extending this to all detected RAM means
  building out proper page tables for the rest via `vmm::map_page` and having
  the PMM bitmap size itself off the E820 map rather than a hardcoded 64 MiB.
- No ring 3 / user mode, no syscalls, no filesystem, no ELF loader for
  external programs — this is a bare kernel, not a full OS yet.
- IRQ handling in this sandbox's headless test environment couldn't be
  keyboard-tested end-to-end (no display backend available for QEMU's key
  injection). The driver code, PIC unmasking, and IDT vector wiring all
  follow the identical pattern already confirmed working for the PIT/timer
  IRQ — worth a real interactive `make run` check when you have a normal
  desktop session.

## License

MIT. See `LICENSE`.
